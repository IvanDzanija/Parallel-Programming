float gettime(void);
